import React from "react";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle";
import './App.css';
import Home from "./Home";
import About from "./About";
import Service from "./Service";
import Contact from "./Contact";
import Admin from "./Admin";
import Patient from "./Patient"
import Doctor from "./Doctor"
import Navbar from "./Navbar";
import { Redirect, Route, Switch } from "react-router";
import Footer from "./Footer";
import ListPatientComponent from "./component/patient/ListPatientComponent";
import AddPatientComponent from "./component/patient/AddPatientComponent";
import ListDoctorComponent from "./component/doctor/ListDoctorComponent";
import AddDoctorComponent from "./component/doctor/AddDoctorComponent";
import EditDoctorComponent from "./component/doctor/EditDoctorComponent";
import ApprovedDoctorComponent from "./component/patient/ApprovedDoctorComponent";
import LoginComponent from "./component/patient/LoginComponent";
import DoctorLoginComponent from "./component/doctor/DoctorLoginComponent";
import PatientService from "./component/patient/PatientServices";
import DoctorService from "./component/doctor/DoctorServices";
import BookAppointmentComponent from "./component/appointment/BookAppointmentComponent";
import GenerateAppointmentComponent from "./component/appointment/GenerateAppointmentComponent";
import AdminLoginComponent from "./component/admin/AdminLoginComponent";
import BookSuccess from "./component/appointment/BookSuccess";
import ListAppointmentComponent from "./component/appointment/ListAppointmentComponent";

const App = () => {
  return (
    <>
    <Navbar />
    <Switch>
        <Route exact path="/" component={Home} />
        <Route exact path="/about" component={About} />
        <Route exact path="/service" component={Service} />
        <Route exact path="/contact" component={Contact} />
        <Route exact path="/adminPage" component={Admin} />
        <Route exact path="/patientPage" component={Patient} />
        <Route exact path="/doctorPage" component={Doctor} />
        <Route path="/admin-login" component={AdminLoginComponent} />
        <Route path="/patient-login" component={LoginComponent} />
        <Route path="/doctor-login" component={DoctorLoginComponent} />
        <Route path="/list" component={ListPatientComponent} />
        <Route path="/add-patient" component={AddPatientComponent} />
        <Route path="/dlist" component={ListDoctorComponent} />
        <Route path="/add-doctor" component={AddDoctorComponent} />
        <Route path="/edit-doctor" component={EditDoctorComponent} />
        <Route path="/approvedList" component={ApprovedDoctorComponent} />
        <Route path="/patient-service" component={PatientService} />
        <Route path="/doctor-service" component={DoctorService} />
        <Route path="/book-app" component={BookAppointmentComponent} />
        <Route path="/generate-app" component={GenerateAppointmentComponent} />
        <Route path="/book-success" component={BookSuccess} />
        <Route path="/alist" component={ListAppointmentComponent} />
        <Redirect to="/" />
      </Switch>
      <Footer />
    </>
  );
}

export default App;
