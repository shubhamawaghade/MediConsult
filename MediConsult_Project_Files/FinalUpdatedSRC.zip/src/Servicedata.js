import admin from "../src/images/admin1.png";
import patient from "../src/images/patient6.jpg";
import doctor from "../src/images/doc.jfif"
const Servicedata = [
    {
        imgsrc: admin,
        title: "Admin",
        visit: "/patients",
        btname: "Go To Admin",
    },
    {
        imgsrc: patient,
        title: "Patient",
        visit:"/list",
        btname: "Go To Patient",
    },
    {
        imgsrc:doctor,
        title: "Doctor",
        visit: "/doctor",
        btname: "Go To Doctor",
    }
];

export default Servicedata;