import React from "react";
import { NavLink , useHistory} from "react-router-dom";

const Doctor = () => {
    return (
        <>
        <>
        
        <div className="jumbotron container px-4">
        <h3 className="display-4 text-center text-primary">Welcome to Doctor</h3>
       
        <div className="row">
        <div class="col">
        <div class="bg-light card-1">
        <NavLink to="/add-doctor" className="nav-link" >Register</NavLink>
        </div>
        </div>
        <div class="col">
        <div class="bg-light card-1">
        <NavLink to="/doctor-login" className="nav-link" >Login</NavLink>
        </div>


        {/* <div class="bg-light">
        <button  className="nav-link" onClick={() => history.push('/login')}>
                  Login
                </button>
        </div> */}
        </div>
        </div>
    </div>
    </>
        </>
    );
}

export default Doctor;