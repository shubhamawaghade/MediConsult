import React, { Component } from "react";
import { NavLink , useHistory} from "react-router-dom";
import ApiService from "../../service/ApiService";

class DoctorLoginComponent extends Component {

    constructor(props) {
        super(props);

        this.state = {
          dEmail: "",
          dPassword: "",
          id:"",
          loading: false,
          message: ""
        };

        this.validate = this.validate.bind(this);
        this.onChange = this.onChange.bind(this);
      }

      componentDidMount() {
      //  this.loadDoctor();
    }

    validate = (event) => {
      event.preventDefault();
      console.log("invalidate");
      let doctor = { 
        dEmail: this.state.dEmail,
        dPassword: this.state.dPassword
      }
      console.log("Email"+this.state.dEmail);
      console.log("Password"+this.state.dPassword);
      
      ApiService.loginDoctor(doctor)
          .then(res => {
            this.setState({message : 'Doctor login successfully.'});
        //    this.setState({doctor: this.state.doctor.filter(doctor => doctor.dEmail == this.state.dEmail && this.state.dPassword) });
        console.log(res.data); 
        sessionStorage.doctor = JSON.stringify(res.data);  
        //sessionStorage.doctor = res.data.id;
            this.props.history.push('/doctor-service');
          });
      console.log(sessionStorage);
    }
      onChange = (event) =>
      this.setState({ [event.target.name]: event.target.value });

    render() {
        return(
          <div className=" global-container">
          <div className="card login-form">
              
              <div className="card-body card d-flex">
                  <h4 className="card-title font-weight-bold text-center">Doctor Login</h4>
                  <form>
                     <div className="form-group input-container">
                     <i class="fa fa-envelope icon"></i>
                      {/* <label>Enter Email:</label> */}
                           <input placeholder="Email" 
                           name="dEmail" 
                          className="form-control" 
                           value={this.state.dEmail} 
                         onChange={this.onChange}/>
                    </div>
      
                       <div className="form-group input-container">
                       <i class="fa fa-key icon"></i>
                          {/* <label>Enter Password:</label> */}
                          <input type="password" 
                           placeholder="password" 
                        name="dPassword" 
                          className="form-control" 
                           value={this.state.dPassword} 
                         onChange={this.onChange}/>
                     </div>
      
                     
                      <button type="button" className="btn1 btn-primary" onClick={this.validate}>Login</button>
                  
                   
                  </form>
                
                  
              </div>
          </div>
      </div>
        );
    }
   
 }
export default DoctorLoginComponent;
