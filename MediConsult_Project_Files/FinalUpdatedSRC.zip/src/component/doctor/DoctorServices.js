import React, { Component } from "react";
import { NavLink} from "react-router-dom";
import ApiService from "../../service/ApiService";

class DoctorService extends Component {

    logout() {
        ApiService.logout()
    }
    render () {
        return(
            <>
            <div className="jumbotron container px-4">
                <h1 className="display-4">Welcome to Doctor Service</h1>
                <p className="lead"></p>
                <hr className="my-4" />
                <p></p>
                <p className="lead">
                <div class="col">
                <div class="bg-light">
                <NavLink to="/generateapp" className="btn btn-Primary" id="btn10">Generate Appointments</NavLink>
                </div>
                <div class="bg-light">
                <NavLink to="/dlist" className="btn btn-Primary" id="btn11">Show Doctors</NavLink>
                </div>
                </div>
                <NavLink to="/service" className="btn btn-success" onClick={this.logout}>Logout</NavLink>
            </p>
            </div>
            </>
        );
    }
}

export default DoctorService;