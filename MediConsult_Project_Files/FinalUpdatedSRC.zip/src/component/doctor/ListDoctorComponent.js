import React, { Component } from 'react';
import ApiService from '../../service/ApiService';
import { NavLink } from "react-router-dom";

class ListDoctorComponent extends Component 
{

    constructor(props) 
        {
            super(props)
            this.state = {
                doctor: [],
                message: null
            }
            this.reloadDoctorList = this.reloadDoctorList.bind(this);
            this.deleteDoctor = this.deleteDoctor.bind(this);
            this.addDoctor = this.addDoctor.bind(this);
        }
        componentDidMount() {
            this.reloadDoctorList();
        }
        addDoctor() {
            window.localStorage.removeItem("doctorId");
            this.props.history.push('/add-doctor');
        }
        deleteDoctor(doctorId) {
            ApiService.deleteDoctor(doctorId)
               .then(res => {
                   this.setState({message : 'Doctor deleted successfully.'});
                   this.setState({doctor: this.state.doctor.filter(doctor => doctor.id !== doctorId)});
               })
        }
        reloadDoctorList() 
        {
            ApiService.fetchDoctors()
            .then((res) => {
                this.setState({doctor: res.data.result})
                console.log(this.state.doctor);
            });
        }
        editDoctor(id) {
            window.localStorage.setItem("doctorId", id);
            this.props.history.push('/edit-doctor');
        }
        render() 
        {
            return (
                <div className="container">
                    <h2 className="text-center">Doctor Details</h2>
                    <button className="btn btn-danger" style={{width:'100px'}} onClick={() => this.addDoctor()}> Add Doctor</button>
                    <NavLink to="/adminPage" className="btn btn-danger float-right" style={{width:'100px'}}>Back To Home</NavLink>
                    <table className="table table-striped">
                        <thead>
                            <tr>
                                <th className="hidden">Id</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>DOB</th>
                                <th>Gender</th>
                                <th>Qualification</th>
                                <th>Specialization</th>
                                <th>Phone Number</th>
                                <th>Verification Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.doctor.map(
                            doctor =>
                                        <tr key={doctor.id}>
                                            <td>{doctor.dName}</td>
                                            <td>{doctor.dEmail}</td>
                                            <td>{doctor.dDob}</td>
                                            <td>{doctor.dGender}</td>
                                            <td>{doctor.qualification}</td>
                                            <td>{doctor.specialization}</td>
                                            <td>{doctor.phoneNos}</td>
                                            <td>{doctor.verificationStatus}</td>
                                            <td>
                                                 <button className="btn btn-success" onClick={() => this.deleteDoctor(doctor.id)}> Delete</button>
                                                <button className="btn btn-success" onClick={() => this.editDoctor(doctor.id)} style={{marginLeft: '20px'}}> Edit</button> 
                                            </td>
                                        </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>
            );
        }
}

export default ListDoctorComponent;