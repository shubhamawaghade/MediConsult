import React, { Component } from 'react'
import ApiService from "../../service/ApiService";

class EditDoctorComponent extends Component {

    constructor(props){
        super(props);
        this.state ={
            id: '',
            dName: '',
            dEmail: '',
            dDob: '',
            dGender: '',
            qualification: '',
            specialization: '',
            phoneNos: '',
            verificationStatus: '',
        }
        this.saveDoctor = this.saveDoctor.bind(this);
        this.loadDoctor = this.loadDoctor.bind(this);
    }

    componentDidMount() {
        this.loadDoctor();
    }

    loadDoctor() {
        ApiService.fetchDoctorById(window.localStorage.getItem("doctorId"))
            .then((res) => {
                let doctor = res.data.result;
                this.setState({
                id: doctor.id,
                dName: doctor.dName,
                dEmail: doctor.dEmail,
                dDob: doctor.dDob,
                dGender: doctor.dGender,
                qualification: doctor.qualification,
                specialization: doctor.specialization,
                phoneNos: doctor.phoneNos,
                verificationStatus: doctor.verificationStatus,
                })
            });
    }

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    saveDoctor = (e) => {
        e.preventDefault();
        let doctor = {id: this.state.id, 
                dName: this.state.dName,
                dEmail: this.state.dEmail,
                dDob: this.state.dDob,
                dGender: this.state.dGender,
                qualification: this.state.qualification,
                specialization: this.state.specialization,
                phoneNos: this.state.phoneNos,
                verificationStatus: this.state.verificationStatus};
        ApiService.editDoctor(doctor)
            .then(res => {
                this.setState({message : 'Doctor updated successfully.'});
                this.props.history.push('/dlist');
            });
    }

    render() {
        return (
            <div>
                <h2 className="text-center">Edit Doctor</h2>
                <form>
                <div className="form-group">
                    <label>Enter Name:</label>
                    <input type="text" placeholder="Name" name="dName" className="form-control" value={this.state.dName} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Enter Password:</label>
                    <input type="password" placeholder="password" name="dPassword" className="form-control" value={this.state.dPassword} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Enter Email:</label>
                    <input placeholder="Email" name="dEmail" className="form-control" value={this.state.dEmail} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Choose Date of Birth:</label>
                    <input type="date" name="dDob" className="form-control" value={this.state.dDob} onChange={this.onChange}/>
                </div>
                <div onChange={this.onChange}>
                    <label>Gender:</label>
                    <input type="radio" value="MALE" name="dGender"/> Male
                    <input type="radio" value="FEMALE" name="dGender"/> Female
                </div>
                <div className="form-group">
                    <label>Qualification:</label>
                    <select  name="qualification"
                        value={this.state.qualification} 
                        onChange={this.onChange}>
						<option value="MBBS">MBBS</option>
						<option value="B.Med">B.Med</option>
						<option value="MD">MD</option>
						<option value="DO">DO</option>
						<option value="DPM">DPM</option>
					</select>		
                </div>

                <div className="form-group">
                    <label>Specialization:</label>
                    <select name="specialization"
                        value={this.state.specialization}
                        onChange={this.onChange}>
						<option value="Orthopedics">Orthopedics</option>
						<option value="Gynecology">Gynecology</option>
						<option value="Pediatrics">Pediatrics</option>
						<option value="Radiology">Radiology</option>
						<option value="General Surgery">General Surgery</option>
					</select>
                </div>

                <div className="form-group">
                    <label>Phone Number:</label>
                    <input type="number" placeholder="Phone Number" name="phoneNos" className="form-control" value={this.state.phoneNos} onChange={this.onChange}/>
                </div>
                    <div className="form-group">
                        <label>Verification Status:</label>
                        <input type="text"  name="verificationStatus" className="form-control" value={this.state.verificationStatus} onChange={this.onChange}/>
                    </div>

                    <button className="btn btn-success bg-large" onClick={this.saveDoctor}>Update</button>
                </form>
            </div>
        );
    }
}

export default EditDoctorComponent;