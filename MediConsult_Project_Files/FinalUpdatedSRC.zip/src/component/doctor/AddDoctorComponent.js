import React, { Component } from 'react'
import ApiService from "../../service/ApiService";

class AddDoctorComponent extends Component{

    constructor(props){
        super(props);
        this.state ={
            dName: '',
            dPassword: '',
            dEmail: '',
            dDob: '',
            dGender: '',
            qualification: '',
            specialization: '',
            phoneNos: '',
            verificationStatus: '',
            message: null
        }
        this.saveDoctor = this.saveDoctor.bind(this);
        this.onChange = this.onChange.bind(this);
    }
    saveDoctor = (d) => {
        d.preventDefault();
        let doctor = 
            {   dName: this.state.dName, 
                dPassword: this.state.dPassword, 
                dEmail: this.state.dEmail, dDob: this.state.dDob,
                dGender: this.state.dGender, 
                qualification: this.state.qualification,
                specialization: this.state.specialization, 
                phoneNos: this.state.phoneNos,
                verificationStatus: this.state.verificationStatus};
        ApiService.addDoctor(doctor)
            .then(res => {
                this.setState({message : 'Doctor added successfully.'});
                this.props.history.push('/dlist');
            });
    }
     
    onChange = (d) =>
        this.setState({ [d.target.name]: d.target.value });

    render() {
        return(
            <>
            
            <h2 className="text-center text-primary text-white">Doctor Registration</h2>
             
                <div className="container card-1">
                   
                    <form className="form1">
                    <div className="form-group">
                        <label>Enter Name:</label>
                        <input type="text" placeholder="Name" name="dName" className="form-control" value={this.state.dName} onChange={this.onChange}/>
                    </div>
    
                    <div className="form-group">
                        <label>Enter Password:</label>
                        <input type="password" placeholder="password" name="dPassword" className="form-control" value={this.state.dPassword} onChange={this.onChange}/>
                    </div>
    
                    <div className="form-group">
                        <label>Enter Email:</label>
                        <input placeholder="Email" name="dEmail" className="form-control" value={this.state.dEmail} onChange={this.onChange}/>
                    </div>
    
                    <div className="form-group">
                        <label>Choose Date of Birth:</label>
                        <input type="date" name="dDob" className="form-control" value={this.state.dDob} onChange={this.onChange}/>
                    </div>
    
                    <div onChange={this.onChange}>
                        <label>Gender:</label>
                        <input type="radio" value="MALE" name="dGender"/> Male
                        <input type="radio" value="FEMALE" name="dGender"/> Female
          
                        {/* <label>Gender:</label>
                        <input type="radio" 
                        value="Male"
                        checked={this.state.selectedOption === "Male"}
                        name="pGender" className="form-control" value={this.state.pGender} onChange={this.onChange}/> */}
                    </div>
    
                    <div className="form-group">
                        <label>Qualification:</label>
                        <select  name="qualification"
                            value={this.state.qualification} 
                            onChange={this.onChange}>
                            <option value="MBBS">MBBS</option>
                            <option value="B.Med">B.Med</option>
                            <option value="MD">MD</option>
                            <option value="DO">DO</option>
                            <option value="DPM">DPM</option>
                        </select>		
                    </div>
    
                    <div className="form-group">
                        <label>Specialization:</label>
                        <select name="specialization"
                            value={this.state.specialization}
                            onChange={this.onChange}>
                            <option value="Orthopedics">Orthopedics</option>
                            <option value="Gynecology">Gynecology</option>
                            <option value="Pediatrics">Pediatrics</option>
                            <option value="Radiology">Radiology</option>
                            <option value="General Surgery">General Surgery</option>
                        </select>
                    </div>
    
                    <div className="form-group">
                        <label>Phone Number:</label>
                        <input type="number" placeholder="Phone Number" name="phoneNos" className="form-control" value={this.state.phoneNos} onChange={this.onChange}/>
                    </div>
    
                    <div className="form-group">
                        <label>Verification Status:</label>
                        <select type="text" name="verificationStatus"  value="PENDING" readonly="true" onChange={this.onChange}>
                        <option value="PENDING">PENDING</option>
                        <option value="APPROVED">APPROVED</option>
                        </select>
                    </div>
    
                    <button className="btn1 btn-primary" onClick={this.saveDoctor}>Save</button>
                </form>
        </div>
        </>
        );
    }
}

export default AddDoctorComponent;