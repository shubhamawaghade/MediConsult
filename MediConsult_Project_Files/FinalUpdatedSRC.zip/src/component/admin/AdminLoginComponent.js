import React, { Component } from "react";
import { NavLink , useHistory} from "react-router-dom";
import ApiService from "../../service/ApiService";

class AdminLoginComponent extends Component {
    constructor(props) {
        super(props);

        this.state = {
          aEmail: "",
          aPassword: "",
          id:"",
          loading: false,
          message: ""
        };

        this.validate = this.validate.bind(this);
        this.onChange = this.onChange.bind(this);
      }

      componentDidMount() {
      //  this.loadDoctor();
    }

    validate = (event) => {
      event.preventDefault();
      console.log("invalidate");
      let admin = { 
        aEmail: this.state.aEmail,
        aPassword: this.state.aPassword
      }
      console.log("Email" + this.state.aEmail);
      console.log("Password" + this.state.aPassword);
      ApiService.loginAdmin(admin)
          .then(res => {
            this.setState({message : 'Admin login successfully.'});
        //    this.setState({doctor: this.state.doctor.filter(doctor => doctor.dEmail == this.state.dEmail && this.state.dPassword) });
        console.log(res.data); 
        sessionStorage.admin = res.data.id;  
        sessionStorage.admin = this.state.aEmail;
            this.props.history.push('/adminPage');
          });
    }

      onChange = (event) =>
      this.setState({ [event.target.name]: event.target.value });

    render() {
        return(
          <div className=" global-container">
          <div className="card login-form">
              
              <div className="card-body card d-flex ">
           
                  <h4 className="card-title font-weight-bold text-center">Admin Login</h4>
                
                  <form>
                     <div className="form-group input-container">
                      {/* <label>Enter Email:</label> */}
                      <i class="fa fa-envelope icon"></i>
                           <input placeholder="Email" 
                           name="aEmail" 
                          className="form-control" 
                           value={this.state.aEmail}            
                         onChange={this.onChange}/>
                    </div>
      
                       <div className="form-group input-container">
                          {/* <label>Enter Password:</label> */}
                          <i class="fa fa-key icon"></i>
                          <input type="password" 
                           placeholder="password" 
                        name="aPassword" 
                          className="form-control" 
                           value={this.state.aPassword} 
                         onChange={this.onChange}/>
                     </div>
                      <button type="button" className="btn1 btn-primary" onClick={this.validate}>Login</button>
                  
                   
                  </form>
                
                  
              </div>
          </div>
      </div>
        );
    }
   
 }
export default AdminLoginComponent;
