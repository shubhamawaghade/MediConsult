import React, { Component } from 'react';
import ApiService from '../../service/ApiService';

class ApprovedDoctorComponent extends Component 
{
    constructor(props) 
        {
            super(props)
            this.state = {
                doctor: [],
                verificationStatus: 'VERIFIED',
                message: null
            }
            this.reloadDoctorList = this.reloadDoctorList.bind(this);
        }
        reloadDoctorList() 
        {
            ApiService.fetchDoctorByStatus(this.state.doctorId,this.state.verificationStatus)
            .then((res) => {
                this.setState({doctor: res.data.result})
                console.log(this.state.doctor);
            });
        }
        
        componentDidMount() {
           this.fetchDoctorByStatus(this.state.doctorId,this.state.verificationStatus);
        }
        
        fetchDoctorByStatus(doctorId,verificationStatus) {
            ApiService.fetchDoctorByStatus(doctorId,verificationStatus)
               .then(res => {
                   this.setState({message : 'Doctor fetched successfully.'});
                   this.setState({doctor: this.state.doctor.filter(doctor => doctor.id !== doctorId && doctor.status !== 'VERIFIED')});
               })
        }
        
        render() 
        {
            return (
                <div className="container">
                    <h2 className="text-center">Doctor Details</h2>
                    {/* <button className="btn btn-danger" style={{width:'100px'}} onClick={() => this.fetchDoctorByStatus(verificationStatus)}>List Doctor</button> */}
                    <table className="table table-striped">
                        <thead>
                            <tr>
                                <th className="hidden">Id</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>DOB</th>
                                <th>Gender</th>
                                <th>Qualification</th>
                                <th>Specialization</th>
                                <th>Phone Number</th>
                                <th>Verification Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.doctor.map(
                            doctor =>
                                        <tr key={doctor.id}>
                                            <td>{doctor.dName}</td>
                                            <td>{doctor.dEmail}</td>
                                            <td>{doctor.dDob}</td>
                                            <td>{doctor.dGender}</td>
                                            <td>{doctor.qualification}</td>
                                            <td>{doctor.specialization}</td>
                                            <td>{doctor.phoneNos}</td>
                                            <td>{doctor.verificationStatus}</td>
                                            <td>
                                                 <button className="btn btn-success" > Book Appointment</button> 
                                            </td>
                                        </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>
            );
        }
}

export default ApprovedDoctorComponent;