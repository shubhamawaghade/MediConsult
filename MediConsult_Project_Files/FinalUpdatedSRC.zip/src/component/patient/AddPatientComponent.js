import React, { Component } from 'react'
import ApiService from "../../service/ApiService";

class AddPatientComponent extends Component{

    constructor(props){
        super(props);
        this.state ={
            pName: '',
            pPassword: '',
            pEmail: '',
            pDob: '',
            pGender: '',
            pCity: '',
            phoneNos: '',
            message: null
        }
        this.savePatient = this.savePatient.bind(this);
    }

    savePatient = (p) => {
        p.preventDefault();
        let patient = 
            {   pName: this.state.pName, 
                pPassword: this.state.pPassword, 
                pEmail: this.state.pEmail, pDob: this.state.pDob, 
                pGender: this.state.pGender, pCity: this.state.pCity,
                phoneNos: this.state.phoneNos};
        ApiService.addPatient(patient)
            .then(res => {
                this.setState({message : 'User added successfully.'});
                this.props.history.push('/list');
            });
    }

    onChange = (p) =>
        this.setState({ [p.target.name]: p.target.value });

    render() {
        return(
            <>
           
            <h2 className="text-center text-primary text-white"> Patient Registration</h2>
             
                
                <div className="container1 card-1 ">
                    
                    <form  className="form1">
                    <div className="form-group">
                        <label>Enter Name:</label>
                        <input type="text" placeholder="Name" name="pName" className="form-control" value={this.state.pName} onChange={this.onChange}/>
                    </div>
    
                    <div className="form-group">
                        <label>Enter Password:</label>
                        <input type="password" placeholder="password" name="pPassword" className="form-control" value={this.state.pPassword} onChange={this.onChange}/>
                    </div>
    
                    <div className="form-group">
                        <label>Enter Email:</label>
                        <input placeholder="Email" name="pEmail" className="form-control" value={this.state.pEmail} onChange={this.onChange}/>
                    </div>
    
                    <div className="form-group">
                        <label>Choose Date of Birth:</label>
                        <input type="date" name="pDob" className="form-control" value={this.state.pDob} onChange={this.onChange}/>
                    </div>
    
                    <div onChange={this.onChange}>
                        <label>Gender:</label>
                        <input type="radio" value="MALE" name="pGender"/> Male
                        <input type="radio" value="FEMALE" name="pGender"/> Female
          
                        {/* <label>Gender:</label>
                        <input type="radio" 
                        value="Male"
                        checked={this.state.selectedOption === "Male"}
                        name="pGender" className="form-control" value={this.state.pGender} onChange={this.onChange}/> */}
                    </div>
    
                    <div className="form-group">
                        <label>City:</label>
                        <input placeholder="City" name="pCity" className="form-control" value={this.state.pCity} onChange={this.onChange}/>
                    </div>
    
                    <div className="form-group">
                        <label>Phone Number:</label>
                        <input type="number" placeholder="Phone Number" name="phoneNos" className="form-control" value={this.state.phoneNos} onChange={this.onChange}/>
                    </div>
    
                    <button className="btn1 btn-primary" onClick={this.savePatient}>Save</button>
                </form>
        </div>
        </>
        );
    }
}

export default AddPatientComponent;