import React, { Component } from 'react';
import ApiService from '../../service/ApiService';
import { NavLink } from "react-router-dom";

class ListPatientComponent extends Component 
{

    constructor(props) 
        {
            super(props)
            this.state = {
                patient: [],
                message: null
            }
            this.reloadPatientList = this.reloadPatientList.bind(this);
            this.deletePatient = this.deletePatient.bind(this);
            this.addPatient = this.addPatient.bind(this);
        }
        componentDidMount() {
            this.reloadPatientList();
        }
        addPatient() {
            window.localStorage.removeItem("patientId");
            this.props.history.push('/add-patient');
        }
        deletePatient(patientId) {
            ApiService.deletePatient(patientId)
               .then(res => {
                   this.setState({message : 'Patient deleted successfully.'});
                   this.setState({patient: this.state.patient.filter(patient => patient.id !== patientId)});
               })
        }
        reloadPatientList() 
        {
            ApiService.fetchPatients()
            .then((res) => {
                this.setState({patient: res.data.result})
                console.log(this.state.patient);
            });
        }
        render() 
        {
            return (
                <div className="container">
                    <h2 className="text-center">Patient Details</h2>
                    <div className="mx-auto" >
                        <button className="btn btn-danger" style={{width:'100px'}} onClick={() => this.addPatient()}> Add Patient</button>
                        <NavLink to="/adminPage" className="btn btn-danger float-right" style={{width:'100px'}}>Back To Home</NavLink>
                    </div>
                    <table className="table table-striped">
                        <thead>
                            <tr>
                                <th className="hidden">Id</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>DOB</th>
                                <th>Gender</th>
                                <th>City</th>
                                <th>Phone Number</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.patient.map(
                            patient =>
                                        <tr key={patient.id}>
                                            <td>{patient.pName}</td>
                                            <td>{patient.pEmail}</td>
                                            <td>{patient.pDob}</td>
                                            <td>{patient.pGender}</td>
                                            <td>{patient.pCity}</td>
                                            <td>{patient.phoneNos}</td>
                                            <td>
                                                 <button className="btn btn-success" onClick={() => this.deletePatient(patient.id)}> Delete</button>
                                               {/* <button className="btn btn-success" onClick={() => this.editUser(user.id)} style={{marginLeft: '20px'}}> Edit</button> */}
                                            </td>
                                        </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>
            );
        }
}

export default ListPatientComponent;