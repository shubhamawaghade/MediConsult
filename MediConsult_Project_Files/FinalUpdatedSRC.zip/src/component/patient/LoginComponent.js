import React, { Component } from "react";
import { NavLink , useHistory} from "react-router-dom";
import ApiService from "../../service/ApiService";

class LoginComponent extends Component {
    constructor(props) {
        super(props);

        this.state = {
          pEmail: "",
          pPassword: "",
          id:"",
          loading: false,
          message: ""
        };

        this.validate = this.validate.bind(this);
        this.onChange = this.onChange.bind(this);
      }

      componentDidMount() {
      //  this.loadDoctor();
    }

    validate = (event) => {
      event.preventDefault();
      console.log("invalidate");
      let patient = { 
        pEmail: this.state.pEmail,
        pPassword: this.state.pPassword
      }
      console.log("Email" + this.state.pEmail);
      console.log("Password" + this.state.pPassword);
      ApiService.loginPatient(patient)
          .then(res => {
            this.setState({message : 'Patient login successfully.'});
        //    this.setState({doctor: this.state.doctor.filter(doctor => doctor.dEmail == this.state.dEmail && this.state.dPassword) });
        console.log(res.data); 
        sessionStorage.patient = JSON.stringify(res.data);  
        //sessionStorage.patient = this.state.pEmail;
            this.props.history.push('/patient-service');
          });
    }

      onChange = (event) =>
      this.setState({ [event.target.name]: event.target.value });

    render() {
        return(
          <div className=" global-container">
          <div className="card login-form">
              
              <div className="card-body card d-flex">
                
                  <h4 className="card-title font-weight-bold text-center ">Patient Login</h4>
                  <form>
                     <div className="form-group input-container">
                      {/* <label>Enter Email:</label> */}
                      <i class="fa fa-envelope icon"></i>
                           <input placeholder="Email" 
                           name="pEmail" 
                          className="form-control" 
                           value={this.state.pEmail} 
                         onChange={this.onChange}/>
                    </div>
      
                       <div className="form-group input-container">
                       <i class="fa fa-key icon"></i>
                          {/* <label>Enter Password:</label> */}
                          <input type="password" 
                           placeholder="password" 
                        name="pPassword" 
                          className="form-control" 
                           value={this.state.pPassword} 
                         onChange={this.onChange}/>
                     </div>
                      <button type="button" className="btn1 btn-primary" onClick={this.validate}>Login</button>
                   
                   
                  </form>
                
                  
              </div>
          </div>
      </div>
        );
    }
   
 }
export default LoginComponent;
