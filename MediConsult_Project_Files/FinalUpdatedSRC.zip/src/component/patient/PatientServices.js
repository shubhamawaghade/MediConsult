import React, { Component } from "react";
import { NavLink} from "react-router-dom";
import ApiService from "../../service/ApiService";

class PatientService extends Component {
    logoutPatient() {
        ApiService.logoutPatient()
    }
    render (){
    return (
        <>
        <div className="jumbotron container px-4">
            <h1 className="display-4">Welcome to Patient Service</h1>
            <p className="lead"></p>
            <hr className="my-4" />
            <p></p>
            <p className="lead">
            <div class="col">
            <div class="bg-light">
            <NavLink to="/book-app" className="nav-link" >Book Appointment</NavLink>
            </div>
            <div class="bg-light">
            <NavLink to="/dlist" className="nav-link" >Show Doctors</NavLink>
            </div>
            </div>
            <NavLink to="/service" className="btn btn-success" onClick={this.logoutPatient}>Logout</NavLink>
        </p>
        </div>
        </>
    );
    
}

}

export default PatientService;