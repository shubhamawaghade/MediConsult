import React, { Component } from 'react'
import { NavLink } from 'react-router-dom';
import ApiService from "../../service/ApiService";

class BookSuccess extends Component {

    constructor(props){
        super(props);
    this.state ={
        aptmtDate: '',
        startTime: '',
        endTime: '',
        appStatus:'BOOKED',
        appointment: [],
        dApp:[],
        pApp:this.loadPatient,
        message: null
    }
    this.BookAppointment = this.BookAppointment.bind(this);
    this.loadAppointments = this.loadAppointments.bind(this);
}
       
    componentDidMount() {
       this.loadAppointments();
    }

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

        loadAppointments() {
            ApiService.fetchAppById(window.localStorage.getItem("appointmentId"))
                .then((res) => {
                    let appointment = res.data.result;
                    this.setState({
                    id: appointment.id,
                    aptmtDate: appointment.aptmtDate,
                    startTime: appointment.startTime,
                    endTime: appointment.endTime,
                    appStatus: appointment.appStatus
                    })
                });
        }
        editAppoint(id) {
            window.localStorage.setItem("appointmentId", id);
            this.props.history.push('/book-success');
        }
        BookAppointment = (a) => {
            a.preventDefault();
            let appointment = {
                aptmtDate: this.state.aptmtDate,
                startTime: this.state.startTime,
                endTime: this.state.endTime,
                appStatus: 'BOOKED',
                   };
            ApiService.editAppointmentStatus(appointment)
                .then(res => {
                    this.setState({message : 'appointment status updated successfully.'});
                 //   this.loadPatient = JSON.parse(window.sessionStorage.getItem('patient'));
                    this.props.history.push('/patient-service');
                });
        }
    

    render() {
        return (
            <div className="container">
                <h2 className="text-center">Appointment Book</h2>
                <form>
                {/* <div className="form-group">
                    <label>Appointment Date :</label>
                    <input type="date" name="aptmtDate" className="form-control" value={this.state.aptmtDate} onChange={this.onChange}/>
                </div> */}

                <div className="form-group">
                    <label>Start time:</label>
                    <input type="time" placeholder="Start time" name="startTime" className="form-control" value={this.state.startTime} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>End time :</label>
                    <input type="time" name="endTime" className="form-control" value={this.state.endTime} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Status :</label>
                    <input type="text" name="appStatus" className="form-control" value='BOOKED' onChange={this.onChange}/>
                </div>

                <div className="form-group">Appointment BOOKED!!! </div>
                <NavLink className="btn btn-success" to="/patient-service">OK</NavLink>
            </form>
            </div>
        );
    }
}

export default BookSuccess;