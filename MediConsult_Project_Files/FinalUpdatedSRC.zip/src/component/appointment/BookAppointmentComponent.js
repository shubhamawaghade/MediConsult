import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import ApiService from '../../service/ApiService';

class BookAppointmentComponent extends Component 
{
    constructor(props){
        super(props);
        this.state ={
            doctor: [],
            appointment: [],
            listOfDoctors: '--Choose Doctor--',
            appList: '--Choose Appointment--',
            dApp: {},
            message: null
        }
        this.dApp = JSON.stringify(this.state.dApp);
     //   this.reloadDoctorList = this.reloadDoctorList.bind(this);
    //    this.loadDoctor = this.loadDoctor.bind(this);
        this.loadAppointments = this.loadAppointments.bind(this);
    }

    componentDidMount() {
     //   this.reloadDoctorList();
      this.loadAppointments();
    }

    // loadDoctor(){
    //     ApiService.fetchDoctorByName(window.localStorage.getItem("specialization"))
    //     .then((res) => {
    //         this.setState({doctor: res.data.result});
    //         this.setState({doctor: this.state.doctor.filter(doctor => doctor.specialization == this.state.specialization)});
            
    //         console.log(this.state.doctor);
    //     });
    // }

    loadAppointments() 
        {
            ApiService.fetchAppointment()
            .then((res) => {
                this.setState({appointment: res.data.result})
              //  this.setState({dApp: res.data.result})
             //   this.setState({doctor: res.data.result})
                console.log(this.state.appointment);
                console.log(this.state.dApp);
            });
        }

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });
    render() 
        {
            const { dApp } = this.state;
            return (
                <div className="container">
                    <h2 className="text-center">Appointment Details</h2>
                    <table className="table table-striped">
                        <thead>
                            <tr>
                                {/* <th className="Hidden">Id</th> */}
                                <th>Appointment Date</th>
                                <th>Start Time</th>
                                <th>End Time</th>
                                <th>Appointment Status</th>
                                <th>Doctor</th>
                                <th>Specialization</th>

                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.appointment.map(
                            appointment =>
                                        <tr key={appointment.id}>
                                            <td>{appointment.aptmtDate}</td>
                                            <td>{appointment.startTime}</td>
                                            <td>{appointment.endTime}</td>
                                            <td>{appointment.appStatus}</td>
                                            <td>{(appointment.dApp)? appointment.dApp.dName:""}</td>
                                            <td>{(appointment.dApp)? appointment.dApp.specialization:""}</td>       
                                            <NavLink className="btn btn-danger" to="/book-success" >Book Appointment</NavLink>  
                                    
                                            {/* <td>
                                                 <button className="btn btn-success" onClick={() => this.deleteDoctor(doctor.id)}> Delete</button>
                                                <button className="btn btn-success" onClick={() => this.editDoctor(doctor.id)} style={{marginLeft: '20px'}}> Edit</button> 
                                            </td> */}
                                        </tr>
                                        
                                )
                            }
                        </tbody>
                    </table>
                </div>
            );
        }
    }

export default BookAppointmentComponent;

                                             
                                    