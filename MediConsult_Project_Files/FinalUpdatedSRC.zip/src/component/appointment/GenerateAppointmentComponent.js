import React, { Component } from 'react';
import ApiService from '../../service/ApiService';

class GenerateAppointmentComponent extends Component 
{

    constructor(props){
        super(props);
        this.saveAppointment = this.saveAppointment.bind(this);
        this.loadDoctor = JSON.parse(window.sessionStorage.getItem('doctor'));
        this.state ={
            aptmtDate: '',
            startTime: '',
            endTime: '',
            appStatus:'AVAILABLE',
            dApp: this.loadDoctor,
            pApp: null,
            message: null
        }
        
    }
    
    // loadDoctor() {
    //     doc=ApiService.fetchDoctorById(window.sessionStorage.getItem('doctor'))
    //         .then((res) => {
    //             let doctor = res.data.result;
    //             this.setState({
    //             id: doctor.id,
    //             dName: doctor.dName,
    //             dEmail: doctor.dEmail,
    //             dDob: doctor.dDob,
    //             dGender: doctor.dGender,
    //             qualification: doctor.qualification,
    //             specialization: doctor.specialization,
    //             phoneNos: doctor.phoneNos,
    //             verificationStatus: doctor.verificationStatus,
    //             })
    //         });
    // }

    saveAppointment = (a) => {
        a.preventDefault();
        console.log(this.loadDoctor);
        let app = 
            {   aptmtDate: this.state.aptmtDate, 
                startTime: this.state.startTime,
                endTime: this.state.endTime,
                appStatus: "AVAILABLE",
                dApp : this.loadDoctor
                //pApp : null
                // currentPayment: this.state.PaymentDetails.currentPayment
                };

        ApiService.generateAppointment(app)
            .then(res => {
                this.setState({message : 'Appointment generated successfully.'});
                console.log(res.data);
                this.props.history.push('/app-list');
            });
    }

    onChange = (p) =>
        this.setState({ [p.target.name]: p.target.value });

    render() {
        return(
            <div className="container">
                <h2 className="text-center">Generate Appointment</h2>
                <form>
                <div className="form-group">
                    <label>Select Appointment Date :</label>
                    <input type="date" placeholder="Date" name="aptmtDate" className="form-control" value={this.state.aptmtDate} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Select start time:</label>
                    <input type="time" placeholder="Start time" name="startTime" className="form-control" value={this.state.startTime} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Select end time :</label>
                    <input type="time" name="endTime" className="form-control" value={this.state.endTime} onChange={this.onChange}/>
                </div>
                {/* <div className="form-group">
                    <label>Payment Details :</label>
                    <input type="number" name="currentPayment" className="form-control" value={this.state.PaymentDetails.currentPayment} onChange={this.onChange}/>
                </div> */}


                <button className="btn btn-success" onClick={this.saveAppointment}>Generate</button>
            </form>
    </div>
        );
    }
}

export default GenerateAppointmentComponent;