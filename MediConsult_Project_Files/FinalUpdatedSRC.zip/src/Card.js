import React from "react";
import { NavLink,useHistory  } from "react-router-dom";
import admin from "../src/images/2.jpg";
import patient from "../src/images/3.jpg";
import doctor from "../src/images/12.jpg"

const Card = () => {

  const history = useHistory();

  return (
    <>
        <div className="col-md-4 col-10 mx-auto">
            <div className="card d-flex header-img card-1">
                <img src={admin} className="card-img-top" alt={admin} height="250px" />
                <div className="card-body">
                    <h4 className="card-title font-weight-bold text-center">Admin</h4>
                    <p className="card-text">There is only one person in this world who can bring life in this world and save life from leaving this world.</p>
                    <button  className="btn btn-primary" onClick={() => history.push('/admin-login')}>
                    <i class="fas fa-arrow-right"></i> Go to Admin
                    </button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-10 mx-auto">
            <div className="card d-flex header-img card-2">
                <img src={patient} className="card-img-top" alt={patient} height="250px" />
                <div className="card-body">
                    <h4 className="card-title font-weight-bold text-center">Patient</h4>
                    <p className="card-text">It is a proud moment for every doctor when he saves a life or when he brings a life in this world.</p>
                    <button  className="btn btn-primary" onClick={() => history.push('/patientPage')}>
                    <i class="fas fa-arrow-right"></i> Go to Patient
                    </button>
                </div>
            </div>
        </div>
        <div className="col-md-4 col-10 mx-auto">
            <div className="card d-flex header-img card-3">
                <img src={doctor} className="card-img-top" alt={doctor} height="250px" />
                <div className="card-body">
                    <h4 className="card-title font-weight-bold text-center"> Doctor</h4>
                    <p className="card-text">The good physician treats the disease; the great physician treats the patient who has the disease.</p>
                    <button  className="btn btn-primary" onClick={() => history.push('/doctorPage')}>
                    <i class="fas fa-arrow-right"></i> Go to Doctor
                    </button>
                </div>
            </div>
        </div>
    </>
  );
}

export default Card;
