import axios from 'axios';

const ADMIN_API_BASE_URL = 'http://localhost:8080/MediConsult/admin';
const PATIENT_API_BASE_URL = 'http://localhost:8080/MediConsult/patient';
const DOCTOR_API_BASE_URL = 'http://localhost:8080/MediConsult/doctor';
const APPOINTMENT_API_BASE_URL = 'http://localhost:8080/MediConsult/appointment';

class ApiService {
    //*********For patient**********//
    loginAdmin(admin) {
        return axios.post(ADMIN_API_BASE_URL +'/'+ admin.aEmail, admin);
    }

    logoutAdmin() {
        sessionStorage.removeItem("admin");
      }


    //*********For patient**********//
    fetchPatients() {
        return axios.get(PATIENT_API_BASE_URL);
    }

//    fetchUserById(userId) {
//         return axios.get(USER_API_BASE_URL + '/' + userId);
//     }

    deletePatient(patientId) {
        return axios.delete(PATIENT_API_BASE_URL + '/' + patientId);
    }

    addPatient(patient) {
        return axios.post(""+PATIENT_API_BASE_URL, patient);
    }

    loginPatient(patient) {
        return axios.post(PATIENT_API_BASE_URL +'/signin/', patient);
    }

    logoutPatient() {
        sessionStorage.removeItem("patient");
      }

//     editUser(user) {
//         return axios.put(USER_API_BASE_URL + '/' + user.id, user);
//     }

     //*********For doctors**********//
    fetchDoctors() {
        return axios.get(DOCTOR_API_BASE_URL);
    }

       fetchDoctorById(doctorId) {
            return axios.get(DOCTOR_API_BASE_URL + '/' + doctorId);
        }

        fetchDoctorByEmailAndPassord(dEmail,dPassword){
            return axios.get(DOCTOR_API_BASE_URL+ '/' + dEmail + ' /' + dPassword)
        }

        fetchDoctorByStatus(doctorId,verificationStatus){
            return axios.get(DOCTOR_API_BASE_URL + '/' + doctorId + '/' + verificationStatus);
        }

    deleteDoctor(doctorId) {
        return axios.delete(DOCTOR_API_BASE_URL + '/' + doctorId);
    }

    addDoctor(doctor) {
        return axios.post(""+DOCTOR_API_BASE_URL, doctor);
    }

    loginDoctor(doctor) {
        return axios.post(DOCTOR_API_BASE_URL +'/signin'+ doctor.dEmail, doctor);
    }

    // getCurrentUser() {
    //     return JSON.parse(localStorage.getItem('doctor'));;
    //   }

      logout() {
        sessionStorage.removeItem("doctor");
      }
    // loginDoctor(doctor) {
    //     return axios.post(""+DOCTOR_API_BASE_URL, doctor);
    // }
        editDoctor(doctor) {
            return axios.put(DOCTOR_API_BASE_URL + doctor.id, doctor);
        }

         //*********For Appointment**********//
        
        fetchAppById(appointmentId) {
            return axios.get(APPOINTMENT_API_BASE_URL + '/' + appointmentId);
        }

        bookAppointment(doctorId){
            return axios.get(APPOINTMENT_API_BASE_URL+ '/getapbydoc/' + doctorId)
        }
        fetchAppointment() {
            return axios.get(APPOINTMENT_API_BASE_URL+ '/app');
        }
        
        generateAppointment(app) {
            return axios.post(""+DOCTOR_API_BASE_URL + '/generateapp',app);
        }

        editAppointmentStatus(appointment) {
            return axios.put(PATIENT_API_BASE_URL + '/bookappointment', appointment);
        }

}

export default new ApiService();