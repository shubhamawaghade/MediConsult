import React, { Component } from "react";
import { NavLink } from "react-router-dom";
import ApiService from "../src/service/ApiService";

class Admin extends Component {
    logoutAdmin() {
        ApiService.logoutAdmin()
    }
    render(){
    return (
        <>
        <div className="jumbotron container px-4">
            <h1 className="display-4">Welcome to Admin</h1>
            <p className="lead"></p>
            <hr className="my-4" />
            <p></p>
            <p className="lead">
            <div class="col">
            <div class="bg-light">
            <NavLink to="/list" className="nav-link">Show Patient List</NavLink>
            </div>
            <div class="bg-light">
            <NavLink to="/dlist" className="nav-link">Show Doctor List</NavLink>
            </div>
            <div class="bg-light">
            <NavLink to="/alist" className="nav-link">Show Appointment List</NavLink>
            </div>
            <div class="bg-light">
            <NavLink to="/service" className="btn btn-success" onClick={this.logoutAdmin}>Logout</NavLink>
            </div>
            </div>
            </p>
        </div>
        </>
    );
    }
}

export default Admin;